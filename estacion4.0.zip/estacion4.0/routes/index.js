var express = require('express');
var router = express.Router();
const MysqlRequest=require("../lib/mysqlconsulta")

const dbConnection = require("../lib/dbConnection")
const connection = dbConnection();

function actualizardatos() {
  datos = MysqlRequest.consultar();
  console.log('Datos', datos);
}

/* GET home page. */
router.get('/', function(req, res, next) {
  connection.query('SELECT * FROM iot.Data ORDER BY f1 DESC LIMIT 2;', (err, result) => {
    console.log(result);
    res.render('index.ejs',{
      news : result
    });
  });
});

router.get('/MNtbjinq4zQCtL3EGUvj', function(req,res,){
  console.log('llego a la peticion(index.js)');
  actualizardatos();
  console.log("indexjs");
  console.log(datos[0]);
  return res.json({data1: datos[0], data2:datos[1],data3:datos[2],data4:datos[3],"hola":"hola"});
  res.render('index', { title: '2' });
  //return res.json({data1: jsonContent.h1})
});

module.exports = router;
